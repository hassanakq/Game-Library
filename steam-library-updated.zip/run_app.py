import threading
import time

import uvicorn
import webview

from backend.main import app, api


def start_server():
    uvicorn.run(
        app,
        host="127.0.0.1",
        port=8000,
        log_level="warning",
    )


if __name__ == "__main__":
    server_thread = threading.Thread(
        target=start_server,
        daemon=True,
    )

    server_thread.start()

    time.sleep(1)

    # frameless + easy_drag hands window dragging to any element with the
    # `pywebview-drag-region` class, which is how the custom title bar in
    # frontend/index.html implements dragging without an OS-drawn frame.
    webview.create_window(
        "Game Library",
        "http://127.0.0.1:8000",
        width=1400,
        height=850,
        min_size=(1000, 650),
        resizable=True,
        frameless=True,
        easy_drag=True,
        background_color="#0a0a0a",
        js_api=api,
    )

    webview.start()
