/**
 * Controller support.
 *
 * The actual gamepad reading happens in Python (backend/controller.py) via
 * pygame's joystick module, which on Windows sits on top of XInput. This
 * file just polls `GameLibraryAPI.get_controller_state()` and turns the
 * result into grid navigation / actions, using the same UI that mouse and
 * keyboard already drive (window.GameLibrary from app.js).
 */

(() => {

    const POLL_INTERVAL_MS = 90;

    const controllerBadge = document.getElementById('controllerBadge');
    const controllerBadgeText = document.getElementById('controllerBadgeText');

    let focusIndex = 0;
    let connected = false;
    let pollTimer = null;

    // --------------------------------------------------------------
    // Grid focus
    // --------------------------------------------------------------

    function gridCards() {
        return Array.from(document.querySelectorAll('#grid .card'));
    }

    function columnsInGrid(cards) {

        if (cards.length === 0) {
            return 1;
        }

        const firstTop = cards[0].offsetTop;

        let columns = 0;

        for (const card of cards) {
            if (card.offsetTop === firstTop) {
                columns += 1;
            } else {
                break;
            }
        }

        return Math.max(1, columns);
    }

    function clearGridFocus() {
        gridCards().forEach(c => c.classList.remove('controller-focused'));
    }

    function applyGridFocus() {

        const cards = gridCards();

        clearGridFocus();

        if (cards.length === 0) {
            return;
        }

        focusIndex = Math.min(focusIndex, cards.length - 1);
        focusIndex = Math.max(focusIndex, 0);

        const card = cards[focusIndex];

        card.classList.add('controller-focused');

        card.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }

    function moveGridFocus(direction) {

        const cards = gridCards();

        if (cards.length === 0) {
            return;
        }

        const columns = columnsInGrid(cards);

        let next = focusIndex;

        if (direction === 'left') {
            next -= 1;
        } else if (direction === 'right') {
            next += 1;
        } else if (direction === 'up') {
            next -= columns;
        } else if (direction === 'down') {
            next += columns;
        }

        if (next < 0) {
            next = 0;
        }

        if (next > cards.length - 1) {
            next = cards.length - 1;
        }

        focusIndex = next;

        applyGridFocus();
    }

    document.addEventListener('gamelibrary:grid-rendered', () => {
        if (connected) {
            applyGridFocus();
        }
    });

    // --------------------------------------------------------------
    // Modal focus
    // --------------------------------------------------------------

    function modalButtons() {
        return Array.from(document.querySelectorAll('#modalActions button'));
    }

    let modalFocusIndex = 0;

    function applyModalFocus() {

        const buttons = modalButtons();

        buttons.forEach(b => b.classList.remove('is-controller-focused'));

        if (buttons.length === 0) {
            return;
        }

        modalFocusIndex = Math.max(0, Math.min(modalFocusIndex, buttons.length - 1));

        buttons[modalFocusIndex].classList.add('is-controller-focused');
        buttons[modalFocusIndex].focus();
    }

    function moveModalFocus(direction) {

        const buttons = modalButtons();

        if (buttons.length === 0) {
            return;
        }

        if (direction === 'left' || direction === 'up') {
            modalFocusIndex -= 1;
        } else if (direction === 'right' || direction === 'down') {
            modalFocusIndex += 1;
        }

        modalFocusIndex =
            (modalFocusIndex + buttons.length) % buttons.length;

        applyModalFocus();
    }

    // --------------------------------------------------------------
    // Action handling
    // --------------------------------------------------------------

    function handleNav(direction) {

        if (!direction) {
            return;
        }

        if (window.GameLibrary.isModalOpen()) {
            moveModalFocus(direction);
        } else {
            moveGridFocus(direction);
        }
    }

    function focusedGame() {

        const games = window.GameLibrary.getRenderedGames();

        return games[focusIndex] || null;
    }

    function handlePressed(action) {

        const modalOpen = window.GameLibrary.isModalOpen();

        if (modalOpen) {

            if (action === 'a') {
                modalButtons()[modalFocusIndex]?.click();
            } else if (action === 'b') {
                window.GameLibrary.closeModal();
            }

            return;
        }

        switch (action) {

            case 'a': {
                const game = focusedGame();
                if (game) window.GameLibrary.launch(game);
                break;
            }

            case 'x': {
                const game = focusedGame();
                if (game) {
                    window.GameLibrary.toggleFavorite(game).then(() => {
                        // Refresh the star's visual state without a full re-render.
                        const card = gridCards()[focusIndex];
                        card?.querySelector('.card-favorite')
                            ?.classList.toggle('is-favorite', !!game.is_favorite);
                    });
                }
                break;
            }

            case 'y': {
                const game = focusedGame();
                if (game) window.GameLibrary.openOptions(game);
                break;
            }

            case 'lb':
                window.GameLibrary.cyclePlatformFilter(-1);
                break;

            case 'rb':
                window.GameLibrary.cyclePlatformFilter(1);
                break;

            case 'start':
                window.GameLibrary.toggleFullscreen();
                break;

            case 'select':
                window.GameLibrary.refresh();
                break;

            case 'b':
                // Nothing to "go back" to at the top level.
                break;
        }
    }

    // --------------------------------------------------------------
    // Polling loop
    // --------------------------------------------------------------

    async function poll() {

        if (!window.pywebview?.api?.get_controller_state) {
            return;
        }

        let state;

        try {
            state = await window.pywebview.api.get_controller_state();
        } catch {
            return;
        }

        if (!state) {
            return;
        }

        if (state.connected && !connected) {

            connected = true;

            if (controllerBadge) {
                controllerBadge.hidden = false;
                controllerBadgeText.textContent =
                    `${state.name || 'controller'} connected`;
            }

            focusIndex = 0;
            applyGridFocus();

        } else if (!state.connected && connected) {

            connected = false;

            if (controllerBadge) {
                controllerBadge.hidden = true;
            }

            clearGridFocus();
        }

        if (!connected) {
            return;
        }

        handleNav(state.nav);

        (state.pressed || []).forEach(handlePressed);
    }

    function start() {

        if (pollTimer) {
            return;
        }

        pollTimer = setInterval(poll, POLL_INTERVAL_MS);
    }

    if (window.pywebview) {
        start();
    } else {
        window.addEventListener('pywebviewready', start);
    }

})();
