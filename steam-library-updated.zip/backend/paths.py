import os
from pathlib import Path

# Persistent application data.
#
# Windows:  %LOCALAPPDATA%\GameLibrary
# Other OS: ~/.gamelibrary   (kept as a sane fallback for local dev)
if os.name == "nt":
    DATA_FOLDER = (
        Path(os.environ.get("LOCALAPPDATA", str(Path.home())))
        / "GameLibrary"
    )
else:
    DATA_FOLDER = Path.home() / ".gamelibrary"

DATA_FOLDER.mkdir(parents=True, exist_ok=True)
